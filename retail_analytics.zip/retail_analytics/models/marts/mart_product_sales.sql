{{ config(materialized='table') }}

WITH product_revenue AS (
    SELECT
        product_id,
        SUM(quantity) AS total_quantity,
        COUNT(DISTINCT order_id) AS total_orders,
        SUM(line_amount) AS total_revenue
    FROM {{ ref('int_sales') }}
    GROUP BY product_id
)

SELECT
    p.product_id,
    COALESCE(r.total_quantity, 0) AS total_quantity,
    COALESCE(r.total_orders, 0) AS total_orders,
    COALESCE(r.total_revenue, 0) AS total_revenue

FROM {{ ref('stg_products') }} p

LEFT JOIN product_revenue r
    ON p.product_id = r.product_id