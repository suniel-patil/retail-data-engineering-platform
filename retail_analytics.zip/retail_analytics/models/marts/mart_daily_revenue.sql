{{ config(materialized='table') }}

SELECT
    CAST(order_date AS DATE) AS order_day,
    COUNT(DISTINCT order_id) AS total_orders,
    SUM(line_amount) AS total_revenue

FROM {{ ref('int_sales') }}

GROUP BY CAST(order_date AS DATE)