{{ config(materialized='table') }}

WITH customer_revenue AS (
    SELECT
        customer_id,
        COUNT(DISTINCT order_id) AS total_orders,
        SUM(line_amount) AS total_revenue
    FROM {{ ref('int_sales') }}
    GROUP BY customer_id
)

SELECT
    c.customer_id,
    COALESCE(r.total_orders, 0) AS total_orders,
    COALESCE(r.total_revenue, 0) AS total_revenue,
    CASE
        WHEN COALESCE(r.total_orders, 0) > 0
        THEN ROUND(r.total_revenue / r.total_orders, 2)
        ELSE 0
    END AS avg_order_value

FROM {{ ref('stg_customers') }} c

LEFT JOIN customer_revenue r
    ON c.customer_id = r.customer_id