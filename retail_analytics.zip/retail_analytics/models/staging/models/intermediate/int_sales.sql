{{ config(materialized='view') }}

WITH orders AS (
    SELECT *
    FROM {{ ref('stg_orders') }}
),

items AS (
    SELECT *
    FROM {{ ref('stg_order_items') }}
)

SELECT
    o.order_id,
    o.customer_id,
    o.order_date,
    i.product_id,
    i.quantity,
    i.unit_price,
    i.quantity * i.unit_price AS line_amount
FROM orders o
INNER JOIN items i
    ON o.order_id = i.order_id
WHERE UPPER(TRIM(o.order_status)) = 'SUCCESS'
  AND i.quantity > 0
  AND i.unit_price >= 0