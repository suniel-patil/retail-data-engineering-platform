{{ config(materialized='view') }}

SELECT
    *
FROM {{ source('retail_silver', 'silver_products') }}