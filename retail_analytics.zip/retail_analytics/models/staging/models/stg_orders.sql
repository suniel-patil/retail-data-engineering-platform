{{ config(materialized='view') }}

SELECT
    order_id,
    customer_id,
    CAST(order_date AS DATE) AS order_date,
    UPPER(TRIM(order_status)) AS order_status,
    CAST(updated_at AS TIMESTAMP) AS updated_at
FROM {{ source('retail_silver', 'silver_orders') }}