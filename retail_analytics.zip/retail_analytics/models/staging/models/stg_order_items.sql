{{ config(materialized='view') }}

SELECT
    *
FROM {{ source('retail_silver', 'silver_order_items') }}