WITH totals AS (

    SELECT
        'detail' AS source_name,
        COALESCE(SUM(line_amount), 0) AS revenue
    FROM {{ ref('int_sales') }}

    UNION ALL

    SELECT
        'daily',
        COALESCE(SUM(total_revenue), 0)
    FROM {{ ref('mart_daily_revenue') }}

    UNION ALL

    SELECT
        'customer',
        COALESCE(SUM(total_revenue), 0)
    FROM {{ ref('mart_customer_sales') }}

    UNION ALL

    SELECT
        'product',
        COALESCE(SUM(total_revenue), 0)
    FROM {{ ref('mart_product_sales') }}
),

reference_total AS (
    SELECT revenue
    FROM totals
    WHERE source_name = 'detail'
)

SELECT
    t.source_name,
    t.revenue,
    r.revenue AS expected_revenue,
    t.revenue - r.revenue AS difference
FROM totals t
CROSS JOIN reference_total r
WHERE ABS(t.revenue - r.revenue) > 0.01




