# Retail Data Engineering — Project Learning Guide

This bundle explains a retail data engineering project using SQL Server, Python, Parquet, Databricks Delta Lake, PySpark, dbt, and Lakeflow Jobs.

Open **Retail_Project_End_to_End_Explained.ipynb** in VS Code/Jupyter, or read **Retail_Project_End_to_End_Explained.md**. The flow diagram is at **docs/data_flow.png**.

**Note:** The explanatory examples are adapted from the project discussion, not a full export of the user's original source files. Several code blocks are templates; do not run the entire notebook on production tables.
